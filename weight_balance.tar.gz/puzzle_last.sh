#!/bin/bash


gnome-terminal -x bash -c "rm -r puzzleproblem.pddl;
						   rm -r puzzleresult.txt;bash -ic;"
