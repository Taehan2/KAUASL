#define VERSION "1.4"
#define HAVE_LINUX 1
#define NDEBUG 1
