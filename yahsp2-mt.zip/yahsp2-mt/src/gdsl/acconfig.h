@BOTTOM@

#undef HAVE_LINUX
#undef HAVE_FREEBSD
#undef HAVE_NETBSD
#undef HAVE_DEBUG

#ifndef HAVE_DEBUG
#define NDEBUG 1
#endif

