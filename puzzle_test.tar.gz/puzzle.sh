#!/bin/bash

gnome-terminal -x bash -c "./popf puzzle_domain.pddl puzzleproblem.pddl > puzzleresult.txt;bash -ic;"
